# ©2022, ANSYS Inc. Unauthorized use, distribution or duplication is prohibited.

__version__ = "0.0.1"
