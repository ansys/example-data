#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_wave_len(Real):
    """
    'beach_wave_len' child.
    """

    fluent_name = "beach-wave-len"

