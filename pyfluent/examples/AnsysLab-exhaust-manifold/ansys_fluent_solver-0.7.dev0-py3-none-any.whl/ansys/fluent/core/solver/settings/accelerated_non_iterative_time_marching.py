#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class accelerated_non_iterative_time_marching(Boolean):
    """
    Enable/disable accelerated non-iterative time marching.
    """

    fluent_name = "accelerated-non-iterative-time-marching?"

