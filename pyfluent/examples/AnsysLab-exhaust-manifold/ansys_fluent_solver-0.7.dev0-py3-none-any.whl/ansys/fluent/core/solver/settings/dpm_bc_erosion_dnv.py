#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_erosion_dnv(Boolean):
    """
    'dpm_bc_erosion_dnv' child.
    """

    fluent_name = "dpm-bc-erosion-dnv?"

