#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class echem_reaction(Boolean):
    """
    'echem_reaction' child.
    """

    fluent_name = "echem-reaction?"

