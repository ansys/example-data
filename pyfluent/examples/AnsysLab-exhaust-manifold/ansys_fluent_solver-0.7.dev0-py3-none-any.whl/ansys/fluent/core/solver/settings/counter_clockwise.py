#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class counter_clockwise(Real):
    """
    'counter_clockwise' child.
    """

    fluent_name = "counter-clockwise"

