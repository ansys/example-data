#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class cylindrical_fixed_var(Boolean):
    """
    'cylindrical_fixed_var' child.
    """

    fluent_name = "cylindrical-fixed-var?"

