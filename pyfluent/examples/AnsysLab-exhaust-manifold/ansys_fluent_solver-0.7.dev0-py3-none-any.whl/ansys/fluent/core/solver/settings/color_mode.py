#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class color_mode(String):
    """
    'color_mode' child.
    """

    fluent_name = "color-mode"

