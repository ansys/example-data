#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class display(Command):
    """
    'display' command.
    """

    fluent_name = "display"

