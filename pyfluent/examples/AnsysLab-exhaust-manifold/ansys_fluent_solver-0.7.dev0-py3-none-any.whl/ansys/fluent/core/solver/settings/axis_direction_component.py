#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

from .child_object_type_child import child_object_type_child

class axis_direction_component(ListObject[child_object_type_child]):
    """
    'axis_direction_component' child.
    """

    fluent_name = "axis-direction-component"

    child_object_type: child_object_type_child = child_object_type_child
    """
    child_object_type of axis_direction_component.
    """
