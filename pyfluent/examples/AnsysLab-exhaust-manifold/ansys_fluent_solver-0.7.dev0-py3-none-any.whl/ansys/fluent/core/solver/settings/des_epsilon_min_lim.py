#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class des_epsilon_min_lim(Real):
    """
    Set minimum allowable epsilon.
    """

    fluent_name = "des-epsilon-min-lim"

