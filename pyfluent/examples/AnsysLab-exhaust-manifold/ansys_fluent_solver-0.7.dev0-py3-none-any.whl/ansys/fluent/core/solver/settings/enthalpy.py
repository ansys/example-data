#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class enthalpy(Real):
    """
    Set reference enthalpy for enthalpy damping and normalization.
    """

    fluent_name = "enthalpy"

