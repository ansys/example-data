#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_erosion_shielding(Boolean):
    """
    'dpm_bc_erosion_shielding' child.
    """

    fluent_name = "dpm-bc-erosion-shielding?"

