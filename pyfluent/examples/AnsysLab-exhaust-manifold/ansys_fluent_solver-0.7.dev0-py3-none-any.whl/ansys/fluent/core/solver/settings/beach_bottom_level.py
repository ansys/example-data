#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_bottom_level(Real):
    """
    'beach_bottom_level' child.
    """

    fluent_name = "beach-bottom-level"

