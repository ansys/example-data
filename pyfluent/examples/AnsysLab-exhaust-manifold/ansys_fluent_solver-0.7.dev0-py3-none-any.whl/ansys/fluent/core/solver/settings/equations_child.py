#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class equations_child(Boolean):
    """
    'child_object_type' of equations.
    """

    fluent_name = "child-object-type"

