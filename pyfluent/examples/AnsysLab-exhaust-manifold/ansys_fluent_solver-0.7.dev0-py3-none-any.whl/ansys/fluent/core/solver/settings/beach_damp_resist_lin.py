#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_damp_resist_lin(Real):
    """
    'beach_damp_resist_lin' child.
    """

    fluent_name = "beach-damp-resist-lin"

