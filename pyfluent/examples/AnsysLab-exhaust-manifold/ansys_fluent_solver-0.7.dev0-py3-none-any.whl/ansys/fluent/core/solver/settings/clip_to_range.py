#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class clip_to_range(Boolean):
    """
    'clip_to_range' child.
    """

    fluent_name = "clip-to-range?"

