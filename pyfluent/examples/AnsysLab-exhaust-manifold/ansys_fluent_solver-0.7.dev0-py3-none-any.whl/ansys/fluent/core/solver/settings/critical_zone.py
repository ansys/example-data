#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class critical_zone(Boolean):
    """
    'critical_zone' child.
    """

    fluent_name = "critical-zone?"

