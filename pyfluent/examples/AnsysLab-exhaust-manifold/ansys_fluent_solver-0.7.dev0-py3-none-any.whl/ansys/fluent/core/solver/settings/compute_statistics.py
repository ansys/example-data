#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class compute_statistics(Boolean):
    """
    Enable/disable solution statistics for contact updates.
    """

    fluent_name = "compute-statistics?"

