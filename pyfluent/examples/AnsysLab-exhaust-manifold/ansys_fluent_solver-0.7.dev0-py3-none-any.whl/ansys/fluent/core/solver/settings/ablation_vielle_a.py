#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class ablation_vielle_a(Real):
    """
    'ablation_vielle_a' child.
    """

    fluent_name = "ablation-vielle-a"

