#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class avg_press_spec(Boolean):
    """
    'avg_press_spec' child.
    """

    fluent_name = "avg-press-spec?"

