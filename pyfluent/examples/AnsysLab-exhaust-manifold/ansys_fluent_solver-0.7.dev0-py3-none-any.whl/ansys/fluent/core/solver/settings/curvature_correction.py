#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class curvature_correction(Boolean):
    """
    Enable/disable the curvature correction.
    """

    fluent_name = "curvature-correction"

