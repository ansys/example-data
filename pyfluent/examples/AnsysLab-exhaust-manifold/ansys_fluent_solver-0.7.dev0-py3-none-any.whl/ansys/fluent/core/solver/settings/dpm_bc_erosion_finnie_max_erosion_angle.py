#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_erosion_finnie_max_erosion_angle(Real):
    """
    'dpm_bc_erosion_finnie_max_erosion_angle' child.
    """

    fluent_name = "dpm-bc-erosion-finnie-max-erosion-angle"

