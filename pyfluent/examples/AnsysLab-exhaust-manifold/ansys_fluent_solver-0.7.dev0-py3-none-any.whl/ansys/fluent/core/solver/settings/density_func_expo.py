#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class density_func_expo(Real):
    """
    Density function exponent.
    """

    fluent_name = "density-func-expo"

