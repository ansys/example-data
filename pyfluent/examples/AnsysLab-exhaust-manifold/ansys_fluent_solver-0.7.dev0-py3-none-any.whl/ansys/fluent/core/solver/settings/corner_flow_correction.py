#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class corner_flow_correction(Boolean):
    """
    Enable/disable the corner flow correction.
    """

    fluent_name = "corner-flow-correction"

