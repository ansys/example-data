#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class alternative_energy_treatment(Boolean):
    """
    Alternative treatment of latent heat source due to mass transfer.
    """

    fluent_name = "alternative-energy-treatment?"

