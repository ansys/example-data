#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_udf(String):
    """
    'dpm_bc_udf' child.
    """

    fluent_name = "dpm-bc-udf"

