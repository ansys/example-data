#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class edges(IntegerList):
    """
    'edges' child.
    """

    fluent_name = "edges"

