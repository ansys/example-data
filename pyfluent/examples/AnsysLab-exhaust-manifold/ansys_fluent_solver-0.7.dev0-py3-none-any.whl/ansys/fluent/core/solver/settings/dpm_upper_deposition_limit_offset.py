#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_upper_deposition_limit_offset(Real):
    """
    'dpm_upper_deposition_limit_offset' child.
    """

    fluent_name = "dpm-upper-deposition-limit-offset"

