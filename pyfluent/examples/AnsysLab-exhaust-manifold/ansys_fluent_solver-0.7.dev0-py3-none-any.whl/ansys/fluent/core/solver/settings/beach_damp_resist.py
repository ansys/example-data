#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_damp_resist(Real):
    """
    'beach_damp_resist' child.
    """

    fluent_name = "beach-damp-resist"

