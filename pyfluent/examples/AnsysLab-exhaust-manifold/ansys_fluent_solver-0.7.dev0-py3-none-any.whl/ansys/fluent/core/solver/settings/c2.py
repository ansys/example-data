#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class c2(Real):
    """
    'c2' child.
    """

    fluent_name = "c2"

