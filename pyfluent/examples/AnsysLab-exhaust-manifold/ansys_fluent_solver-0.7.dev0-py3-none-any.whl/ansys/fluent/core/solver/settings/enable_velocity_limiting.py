#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class enable_velocity_limiting(Boolean):
    """
    Enable/disable velocity limiting treatment.
    """

    fluent_name = "enable-velocity-limiting?"

