#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_len_factor(Real):
    """
    'beach_len_factor' child.
    """

    fluent_name = "beach-len-factor"

