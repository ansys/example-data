#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class disable_casm(Command):
    """
    'disable_casm' command.
    """

    fluent_name = "disable-casm"

