#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_id(Integer):
    """
    'beach_id' child.
    """

    fluent_name = "beach-id"

