#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_wall_heat_exchange(Boolean):
    """
    'dpm_wall_heat_exchange' child.
    """

    fluent_name = "dpm-wall-heat-exchange?"

