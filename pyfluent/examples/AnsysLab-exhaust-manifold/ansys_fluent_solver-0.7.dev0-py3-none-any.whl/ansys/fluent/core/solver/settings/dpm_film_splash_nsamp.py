#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_film_splash_nsamp(Integer):
    """
    'dpm_film_splash_nsamp' child.
    """

    fluent_name = "dpm-film-splash-nsamp"

