#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class display_state_name(String):
    """
    'display_state_name' child.
    """

    fluent_name = "display-state-name"

