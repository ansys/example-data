#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class enable_dynamic_strength(Boolean):
    """
    Enable dynamic strength to reduce compression in the tangential direction to the interface.
    """

    fluent_name = "enable-dynamic-strength?"

