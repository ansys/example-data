#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

from .child_object_type_child import child_object_type_child

class band_q_irrad_diffuse(NamedObject[child_object_type_child]):
    """
    'band_q_irrad_diffuse' child.
    """

    fluent_name = "band-q-irrad-diffuse"

    child_object_type: child_object_type_child = child_object_type_child
    """
    child_object_type of band_q_irrad_diffuse.
    """
