#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class auto_time_solid_scale_factor(Real):
    """
    Auto Time Step Size Scaling Factor for solid zones.
    """

    fluent_name = "auto-time-solid-scale-factor"

