#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_calibratable_temp(Real):
    """
    'dpm_calibratable_temp' child.
    """

    fluent_name = "dpm-calibratable-temp"

