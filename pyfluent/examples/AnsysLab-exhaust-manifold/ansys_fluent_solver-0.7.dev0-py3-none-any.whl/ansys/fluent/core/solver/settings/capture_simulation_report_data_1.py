#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class capture_simulation_report_data(Boolean):
    """
    Capture Simulation Report Data option for Design Point.
    """

    fluent_name = "capture-simulation-report-data"

