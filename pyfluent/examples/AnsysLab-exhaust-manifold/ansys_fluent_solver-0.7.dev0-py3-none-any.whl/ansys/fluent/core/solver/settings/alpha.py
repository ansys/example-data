#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class alpha(Real):
    """
    'alpha' child.
    """

    fluent_name = "alpha"

