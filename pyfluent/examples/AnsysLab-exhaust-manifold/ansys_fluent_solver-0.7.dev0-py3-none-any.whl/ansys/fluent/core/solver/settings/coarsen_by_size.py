#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class coarsen_by_size(Integer):
    """
    'coarsen_by_size' child.
    """

    fluent_name = "coarsen-by-size"

