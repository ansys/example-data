#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_damp_len_spec(String):
    """
    'beach_damp_len_spec' child.
    """

    fluent_name = "beach-damp-len-spec"

