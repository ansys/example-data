#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class convert_to_managed(Boolean):
    """
    'convert_to_managed' child.
    """

    fluent_name = "convert-to-managed"

