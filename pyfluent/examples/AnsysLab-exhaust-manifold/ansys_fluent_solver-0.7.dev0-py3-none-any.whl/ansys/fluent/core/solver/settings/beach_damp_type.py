#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_damp_type(String):
    """
    'beach_damp_type' child.
    """

    fluent_name = "beach-damp-type"

