#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_start_point(Real):
    """
    'beach_start_point' child.
    """

    fluent_name = "beach-start-point"

