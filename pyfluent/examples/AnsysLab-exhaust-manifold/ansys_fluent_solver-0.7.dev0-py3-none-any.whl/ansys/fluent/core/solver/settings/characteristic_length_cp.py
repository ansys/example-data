#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class characteristic_length_cp(Real):
    """
    'characteristic_length_cp' child.
    """

    fluent_name = "characteristic-length-cp"

