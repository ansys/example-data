#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class enhanced_numerics(Boolean):
    """
    Multiphase enhanced compressible flow numerics options.
    """

    fluent_name = "enhanced-numerics?"

