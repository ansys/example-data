#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class design_points(StringList):
    """
    'design_points' child.
    """

    fluent_name = "design-points"

