#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_film_condensation(Boolean):
    """
    'dpm_film_condensation' child.
    """

    fluent_name = "dpm-film-condensation?"

