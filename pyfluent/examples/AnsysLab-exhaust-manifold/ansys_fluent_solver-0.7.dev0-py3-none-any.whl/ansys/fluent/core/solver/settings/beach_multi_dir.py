#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_multi_dir(Boolean):
    """
    'beach_multi_dir' child.
    """

    fluent_name = "beach-multi-dir?"

