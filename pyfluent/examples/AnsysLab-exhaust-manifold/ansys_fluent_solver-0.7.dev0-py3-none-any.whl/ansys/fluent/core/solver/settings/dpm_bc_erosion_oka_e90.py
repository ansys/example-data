#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_erosion_oka_e90(Real):
    """
    'dpm_bc_erosion_oka_e90' child.
    """

    fluent_name = "dpm-bc-erosion-oka-e90"

