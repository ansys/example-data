#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class characteristic_length(Real):
    """
    'characteristic_length' child.
    """

    fluent_name = "characteristic-length"

