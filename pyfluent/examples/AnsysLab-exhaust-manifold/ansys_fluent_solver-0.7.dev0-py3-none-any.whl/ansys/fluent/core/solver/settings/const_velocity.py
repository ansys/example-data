#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class const_velocity(Boolean):
    """
    Enable/Disable constant velocity magnitude.
    """

    fluent_name = "const-velocity?"

