#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_particle_stripping(Boolean):
    """
    'dpm_particle_stripping' child.
    """

    fluent_name = "dpm-particle-stripping?"

