#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_dir_nk(Real):
    """
    'beach_dir_nk' child.
    """

    fluent_name = "beach-dir-nk"

