#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class coarsen_by_interval(Integer):
    """
    Coupled:coarsen by interval.
    """

    fluent_name = "coarsen-by-interval"

