#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class correction_tolerance_child(Real):
    """
    'child_object_type' of correction_tolerance.
    """

    fluent_name = "child-object-type"

