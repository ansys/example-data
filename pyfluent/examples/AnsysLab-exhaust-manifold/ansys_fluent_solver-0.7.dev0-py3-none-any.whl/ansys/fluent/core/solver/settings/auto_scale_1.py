#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class auto_scale(Command):
    """
    'auto_scale' command.
    """

    fluent_name = "auto-scale"

