#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class alternate_diffusion_for_porous_region_solids(Boolean):
    """
    Enable/disable use of alternate diffusion for porous region solids.
    """

    fluent_name = "alternate-diffusion-for-porous-region-solids?"

