#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class blended_treatment_for_buoyancy_forces(Boolean):
    """
    Enable/disable use of  blended treatment for buoyancy force.
    """

    fluent_name = "blended-treatment-for-buoyancy-forces?"

