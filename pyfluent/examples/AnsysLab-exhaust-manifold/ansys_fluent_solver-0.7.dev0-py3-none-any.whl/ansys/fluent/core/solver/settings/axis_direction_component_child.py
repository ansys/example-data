#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class axis_direction_component_child(Real):
    """
    'child_object_type' of axis_direction_component.
    """

    fluent_name = "child-object-type"

