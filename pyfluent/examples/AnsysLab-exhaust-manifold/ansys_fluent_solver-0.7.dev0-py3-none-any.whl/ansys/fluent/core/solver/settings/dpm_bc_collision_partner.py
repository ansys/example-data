#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_collision_partner(String):
    """
    'dpm_bc_collision_partner' child.
    """

    fluent_name = "dpm-bc-collision-partner"

