#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_allow_vof_to_lwf(Boolean):
    """
    'dpm_allow_vof_to_lwf' child.
    """

    fluent_name = "dpm-allow-vof-to-lwf?"

