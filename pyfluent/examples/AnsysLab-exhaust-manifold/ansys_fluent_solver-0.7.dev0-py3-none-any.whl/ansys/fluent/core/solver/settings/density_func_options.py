#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class density_func_options(Integer):
    """
    Density function option.
    """

    fluent_name = "density-func-options"

