#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class coefficient(Real):
    """
    Multi-stage coefficient.
    """

    fluent_name = "coefficient"

