#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class cell_to_limiting(String):
    """
    Cell to face limiting ([no] for cell to cell limiting) .
    """

    fluent_name = "cell-to-limiting"

