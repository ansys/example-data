#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class density_ratio_cutoff(Real):
    """
    Density ratio cut-off.
    """

    fluent_name = "density-ratio-cutoff"

