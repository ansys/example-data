#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class cone_angle(Real):
    """
    'cone_angle' child.
    """

    fluent_name = "cone-angle"

