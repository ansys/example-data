#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class enhanced_casm_formulation(Boolean):
    """
    Enable/disable use of enhanced CASM formulation.
    """

    fluent_name = "enhanced-casm-formulation?"

