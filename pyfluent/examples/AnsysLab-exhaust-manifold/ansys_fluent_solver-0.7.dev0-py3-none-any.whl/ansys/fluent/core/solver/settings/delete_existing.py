#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class delete_existing(Boolean):
    """
    'delete_existing' child.
    """

    fluent_name = "delete-existing"

