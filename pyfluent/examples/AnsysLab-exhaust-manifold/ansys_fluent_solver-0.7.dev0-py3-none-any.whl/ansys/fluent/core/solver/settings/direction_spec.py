#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class direction_spec(String):
    """
    'direction_spec' child.
    """

    fluent_name = "direction-spec"

