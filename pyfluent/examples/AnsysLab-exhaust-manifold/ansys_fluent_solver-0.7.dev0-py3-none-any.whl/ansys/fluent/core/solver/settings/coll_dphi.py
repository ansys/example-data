#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class coll_dphi(Real):
    """
    'coll_dphi' child.
    """

    fluent_name = "coll-dphi"

