#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class correction_reduction(Real):
    """
    Correction relaxation factor.
    """

    fluent_name = "correction-reduction"

