#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class bubble_number_density(Real):
    """
    Set bubble number density.
    """

    fluent_name = "bubble-number-density"

