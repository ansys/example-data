#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dir(Integer):
    """
    'dir' child.
    """

    fluent_name = "dir"

