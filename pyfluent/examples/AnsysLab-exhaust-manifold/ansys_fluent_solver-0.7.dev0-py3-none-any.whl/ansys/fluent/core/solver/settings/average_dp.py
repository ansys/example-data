#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class average_dp(Boolean):
    """
    'average_dp' child.
    """

    fluent_name = "average-dp?"

