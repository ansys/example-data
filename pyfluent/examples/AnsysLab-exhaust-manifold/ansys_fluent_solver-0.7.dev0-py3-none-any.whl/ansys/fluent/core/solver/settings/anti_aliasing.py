#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class anti_aliasing(String):
    """
    'anti_aliasing' child.
    """

    fluent_name = "anti-aliasing"

