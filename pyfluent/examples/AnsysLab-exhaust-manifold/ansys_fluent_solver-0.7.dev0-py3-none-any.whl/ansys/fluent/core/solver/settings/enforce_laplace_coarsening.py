#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class enforce_laplace_coarsening(Boolean):
    """
    Enable/disable the use of laplace coarsening in AMG.
    """

    fluent_name = "enforce-laplace-coarsening?"

