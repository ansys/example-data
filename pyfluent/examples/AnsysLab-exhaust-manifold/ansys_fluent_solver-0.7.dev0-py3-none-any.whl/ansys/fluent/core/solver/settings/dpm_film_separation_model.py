#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_film_separation_model(String):
    """
    'dpm_film_separation_model' child.
    """

    fluent_name = "dpm-film-separation-model"

