#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_initial_height(Real):
    """
    'dpm_initial_height' child.
    """

    fluent_name = "dpm-initial-height"

