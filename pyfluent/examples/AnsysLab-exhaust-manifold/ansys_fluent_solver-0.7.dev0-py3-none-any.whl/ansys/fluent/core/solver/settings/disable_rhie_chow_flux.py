#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class disable_rhie_chow_flux(Boolean):
    """
    Use low order velocity interpolation in flux calculation.
    """

    fluent_name = "disable-rhie-chow-flux?"

