#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dt_init_limit(Real):
    """
    Set maximum value for pseudo time step size during first iteration.
    """

    fluent_name = "dt-init-limit"

