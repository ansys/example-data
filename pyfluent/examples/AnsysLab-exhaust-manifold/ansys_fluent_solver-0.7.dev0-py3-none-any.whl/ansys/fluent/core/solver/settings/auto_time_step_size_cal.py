#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class auto_time_step_size_cal(Boolean):
    """
    Enable/disable use of automatic time step size calculation.
    """

    fluent_name = "auto-time-step-size-cal?"

