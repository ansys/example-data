#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class anisotropic_spe_diff(Boolean):
    """
    'anisotropic_spe_diff' child.
    """

    fluent_name = "anisotropic-spe-diff?"

