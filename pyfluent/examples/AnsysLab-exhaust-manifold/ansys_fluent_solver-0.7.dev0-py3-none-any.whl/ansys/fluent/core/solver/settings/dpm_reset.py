#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_reset(Command):
    """
    Reset discrete phase source terms to zero.
    """

    fluent_name = "dpm-reset"

