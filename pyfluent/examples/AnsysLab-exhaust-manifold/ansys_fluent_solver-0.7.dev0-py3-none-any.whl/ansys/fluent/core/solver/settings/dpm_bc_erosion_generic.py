#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_erosion_generic(Boolean):
    """
    'dpm_bc_erosion_generic' child.
    """

    fluent_name = "dpm-bc-erosion-generic?"

