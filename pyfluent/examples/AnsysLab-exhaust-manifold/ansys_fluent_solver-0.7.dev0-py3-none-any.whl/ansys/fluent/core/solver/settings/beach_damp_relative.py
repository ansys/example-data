#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_damp_relative(Boolean):
    """
    'beach_damp_relative' child.
    """

    fluent_name = "beach-damp-relative?"

