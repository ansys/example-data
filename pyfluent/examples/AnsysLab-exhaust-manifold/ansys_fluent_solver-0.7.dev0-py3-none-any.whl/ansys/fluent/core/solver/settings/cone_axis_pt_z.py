#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class cone_axis_pt_z(Real):
    """
    'cone_axis_pt_z' child.
    """

    fluent_name = "cone-axis-pt-z"

