#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class auto_range(Group):
    """
    'auto_range' child.
    """

    fluent_name = "auto-range"

