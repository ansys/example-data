#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class auto_time_step_size_scale_factor(Real):
    """
    Auto Time Step Size Scaling Factor.
    """

    fluent_name = "auto-time-step-size-scale-factor"

