#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_erosion_mclaury_y(Real):
    """
    'dpm_bc_erosion_mclaury_y' child.
    """

    fluent_name = "dpm-bc-erosion-mclaury-y"

