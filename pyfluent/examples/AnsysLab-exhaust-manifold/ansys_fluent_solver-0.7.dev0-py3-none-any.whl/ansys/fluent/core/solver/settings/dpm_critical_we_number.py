#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_critical_we_number(Real):
    """
    'dpm_critical_we_number' child.
    """

    fluent_name = "dpm-critical-we-number"

