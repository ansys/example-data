#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_allow_lwf_to_vof(Boolean):
    """
    'dpm_allow_lwf_to_vof' child.
    """

    fluent_name = "dpm-allow-lwf-to-vof?"

