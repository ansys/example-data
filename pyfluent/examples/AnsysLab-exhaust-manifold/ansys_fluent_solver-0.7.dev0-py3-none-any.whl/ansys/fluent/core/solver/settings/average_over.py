#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class average_over(Integer):
    """
    'average_over' child.
    """

    fluent_name = "average-over"

