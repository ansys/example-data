#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class adhesion_constrained(Boolean):
    """
    'adhesion_constrained' child.
    """

    fluent_name = "adhesion-constrained?"

