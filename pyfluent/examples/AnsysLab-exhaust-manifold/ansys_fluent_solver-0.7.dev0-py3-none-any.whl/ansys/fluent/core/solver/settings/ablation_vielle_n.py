#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class ablation_vielle_n(Real):
    """
    'ablation_vielle_n' child.
    """

    fluent_name = "ablation-vielle-n"

