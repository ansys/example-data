#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class arrow_space(Real):
    """
    'arrow_space' child.
    """

    fluent_name = "arrow-space"

