#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class differential_viscosity_model(Boolean):
    """
    Enable/disable the differential-viscosity model.
    """

    fluent_name = "differential-viscosity-model"

