#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class boundary_treatment(Boolean):
    """
     Enable/disable modified/extended boundary treatment.
    """

    fluent_name = "boundary-treatment"

