#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class ecad_name(String):
    """
    'ecad_name' child.
    """

    fluent_name = "ecad-name"

