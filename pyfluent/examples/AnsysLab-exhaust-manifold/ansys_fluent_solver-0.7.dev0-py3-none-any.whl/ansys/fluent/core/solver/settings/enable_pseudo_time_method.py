#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class enable_pseudo_time_method(Boolean):
    """
    'enable_pseudo_time_method' child.
    """

    fluent_name = "enable-pseudo-time-method?"

