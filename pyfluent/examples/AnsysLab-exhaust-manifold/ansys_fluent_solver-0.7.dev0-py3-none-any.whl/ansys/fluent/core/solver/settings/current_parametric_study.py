#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class current_parametric_study(String):
    """
    Name of Current Parametric Study.
    """

    fluent_name = "current-parametric-study"

