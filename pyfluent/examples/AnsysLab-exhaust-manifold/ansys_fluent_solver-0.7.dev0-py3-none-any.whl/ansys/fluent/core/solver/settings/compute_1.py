#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

from .compute import compute
class compute(Group):
    """
    'compute' child.
    """

    fluent_name = "compute"

    child_names = \
        ['compute']

    compute: compute = compute
    """
    compute child of compute.
    """
