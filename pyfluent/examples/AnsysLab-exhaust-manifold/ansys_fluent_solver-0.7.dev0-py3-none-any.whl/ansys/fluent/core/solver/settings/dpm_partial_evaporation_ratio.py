#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_partial_evaporation_ratio(Real):
    """
    'dpm_partial_evaporation_ratio' child.
    """

    fluent_name = "dpm-partial-evaporation-ratio"

