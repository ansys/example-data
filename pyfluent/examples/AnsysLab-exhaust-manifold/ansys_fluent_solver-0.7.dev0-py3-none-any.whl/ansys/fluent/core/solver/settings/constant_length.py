#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class constant_length(Real):
    """
    'constant_length' child.
    """

    fluent_name = "constant-length"

