#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class desired_cfl(Real):
    """
    Set Courant Number.
    """

    fluent_name = "desired-cfl"

