#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_film_separation_angle(Real):
    """
    'dpm_film_separation_angle' child.
    """

    fluent_name = "dpm-film-separation-angle"

