#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_erosion_shear_packing_limit(Real):
    """
    'dpm_bc_erosion_shear_packing_limit' child.
    """

    fluent_name = "dpm-bc-erosion-shear-packing-limit"

