#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class coefficients(RealList):
    """
    'coefficients' child.
    """

    fluent_name = "coefficients"

