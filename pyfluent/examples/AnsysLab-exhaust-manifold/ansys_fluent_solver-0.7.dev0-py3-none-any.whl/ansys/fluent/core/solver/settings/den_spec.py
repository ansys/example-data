#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class den_spec(String):
    """
    'den_spec' child.
    """

    fluent_name = "den-spec"

