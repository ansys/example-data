#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_erosion_mclaury_vel_exp(Real):
    """
    'dpm_bc_erosion_mclaury_vel_exp' child.
    """

    fluent_name = "dpm-bc-erosion-mclaury-vel-exp"

