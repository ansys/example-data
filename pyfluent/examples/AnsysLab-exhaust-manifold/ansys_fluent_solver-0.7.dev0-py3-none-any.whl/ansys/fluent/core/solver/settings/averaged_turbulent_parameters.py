#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class averaged_turbulent_parameters(Boolean):
    """
    Enable/Disable averaged turbulent parameters.
    """

    fluent_name = "averaged-turbulent-parameters?"

