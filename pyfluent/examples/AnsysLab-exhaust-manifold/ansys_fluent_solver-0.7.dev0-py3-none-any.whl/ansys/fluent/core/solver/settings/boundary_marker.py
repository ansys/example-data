#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class boundary_marker(String):
    """
    'boundary_marker' child.
    """

    fluent_name = "boundary-marker"

