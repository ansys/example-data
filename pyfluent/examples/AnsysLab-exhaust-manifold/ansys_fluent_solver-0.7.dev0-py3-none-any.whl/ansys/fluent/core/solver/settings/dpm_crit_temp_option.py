#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_crit_temp_option(String):
    """
    'dpm_crit_temp_option' child.
    """

    fluent_name = "dpm-crit-temp-option"

