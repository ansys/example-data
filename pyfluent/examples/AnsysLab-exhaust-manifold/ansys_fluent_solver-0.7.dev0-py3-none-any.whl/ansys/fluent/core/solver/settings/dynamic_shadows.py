#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dynamic_shadows(String):
    """
    'dynamic_shadows' child.
    """

    fluent_name = "dynamic-shadows"

