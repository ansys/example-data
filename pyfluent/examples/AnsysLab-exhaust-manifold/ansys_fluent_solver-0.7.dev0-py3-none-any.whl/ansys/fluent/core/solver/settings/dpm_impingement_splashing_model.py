#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_impingement_splashing_model(String):
    """
    'dpm_impingement_splashing_model' child.
    """

    fluent_name = "dpm-impingement-splashing-model"

