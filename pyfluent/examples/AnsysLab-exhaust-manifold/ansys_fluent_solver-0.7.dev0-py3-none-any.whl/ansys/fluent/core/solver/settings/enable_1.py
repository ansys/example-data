#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class enable(Boolean):
    """
    Enable advanced automatic time stepping for better stability.
    """

    fluent_name = "enable?"

