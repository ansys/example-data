#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class coupled_solver(String):
    """
    Select pseudo time step size formulation for the pseudo time method.
    """

    fluent_name = "coupled-solver"

