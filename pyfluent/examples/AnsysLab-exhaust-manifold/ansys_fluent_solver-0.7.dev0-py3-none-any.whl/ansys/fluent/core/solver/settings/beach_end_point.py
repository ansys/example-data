#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_end_point(Real):
    """
    'beach_end_point' child.
    """

    fluent_name = "beach-end-point"

