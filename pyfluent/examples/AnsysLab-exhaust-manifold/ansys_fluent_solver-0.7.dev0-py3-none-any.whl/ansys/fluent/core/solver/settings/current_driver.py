#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class current_driver(Command):
    """
    'current_driver' command.
    """

    fluent_name = "current-driver"

