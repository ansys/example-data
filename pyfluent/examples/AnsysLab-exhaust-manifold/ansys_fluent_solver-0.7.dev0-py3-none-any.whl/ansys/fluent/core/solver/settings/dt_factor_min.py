#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dt_factor_min(Real):
    """
    Set minimum time step size change factor.
    """

    fluent_name = "dt-factor-min"

