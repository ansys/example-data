#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dual_potential_type(String):
    """
    'dual_potential_type' child.
    """

    fluent_name = "dual-potential-type"

