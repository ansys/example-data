#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class ablation_surfacerxn_density(Real):
    """
    'ablation_surfacerxn_density' child.
    """

    fluent_name = "ablation-surfacerxn-density"

