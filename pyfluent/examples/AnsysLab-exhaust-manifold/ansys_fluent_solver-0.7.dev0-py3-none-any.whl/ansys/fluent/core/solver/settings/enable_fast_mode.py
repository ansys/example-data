#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class enable_fast_mode(Boolean):
    """
    Enable/disable use of fast mode.
    """

    fluent_name = "enable-fast-mode"

