#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class cursys_name(String):
    """
    'cursys_name' child.
    """

    fluent_name = "cursys-name"

