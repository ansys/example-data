#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_erosion_oka_n1(Real):
    """
    'dpm_bc_erosion_oka_n1' child.
    """

    fluent_name = "dpm-bc-erosion-oka-n1"

