#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_bc_erosion_dnv_k(Real):
    """
    'dpm_bc_erosion_dnv_k' child.
    """

    fluent_name = "dpm-bc-erosion-dnv-k"

