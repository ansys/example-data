#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class enable_memory_saving_mode(Boolean):
    """
    Enable/disable use of Memory Saving Mode.
    """

    fluent_name = "enable-memory-saving-mode"

