#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class cycle_type(String):
    """
    'cycle_type' child.
    """

    fluent_name = "cycle-type"

