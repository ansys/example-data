#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class adjust_solver_defaults_based_on_setup(Boolean):
    """
    Enable/disable adjustment of solver defaults based on setup.
    """

    fluent_name = "adjust-solver-defaults-based-on-setup"

