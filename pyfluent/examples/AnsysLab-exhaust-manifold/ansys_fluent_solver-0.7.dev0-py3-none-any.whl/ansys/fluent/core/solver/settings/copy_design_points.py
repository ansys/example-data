#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class copy_design_points(Boolean):
    """
    'copy_design_points' child.
    """

    fluent_name = "copy-design-points"

