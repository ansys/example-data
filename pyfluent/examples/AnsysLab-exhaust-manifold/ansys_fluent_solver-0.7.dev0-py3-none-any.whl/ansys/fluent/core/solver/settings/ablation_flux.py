#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class ablation_flux(Boolean):
    """
    'ablation_flux' child.
    """

    fluent_name = "ablation-flux?"

