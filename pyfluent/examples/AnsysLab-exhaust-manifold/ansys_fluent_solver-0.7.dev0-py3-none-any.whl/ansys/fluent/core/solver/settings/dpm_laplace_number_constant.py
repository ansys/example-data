#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_laplace_number_constant(Real):
    """
    'dpm_laplace_number_constant' child.
    """

    fluent_name = "dpm-laplace-number-constant"

