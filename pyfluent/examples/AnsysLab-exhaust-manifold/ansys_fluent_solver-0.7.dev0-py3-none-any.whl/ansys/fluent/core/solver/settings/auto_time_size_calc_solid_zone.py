#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class auto_time_size_calc_solid_zone(Boolean):
    """
    Enable/disable automatic time step size calculation for solid zone.
    """

    fluent_name = "auto-time-size-calc-solid-zone?"

