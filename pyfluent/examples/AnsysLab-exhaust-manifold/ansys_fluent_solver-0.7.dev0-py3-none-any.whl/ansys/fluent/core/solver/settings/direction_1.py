#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class direction_1(RealList):
    """
    'direction_1' child.
    """

    fluent_name = "direction-1"

