#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class control_time_step_size_variation(Boolean):
    """
    Enter Control time step size variation.
    """

    fluent_name = "control-time-step-size-variation?"

