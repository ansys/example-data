#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class archive_name(String):
    """
    'archive_name' child.
    """

    fluent_name = "archive-name"

