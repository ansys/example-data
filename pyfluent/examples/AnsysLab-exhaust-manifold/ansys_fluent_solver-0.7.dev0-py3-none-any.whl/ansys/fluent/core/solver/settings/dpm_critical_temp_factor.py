#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dpm_critical_temp_factor(Real):
    """
    'dpm_critical_temp_factor' child.
    """

    fluent_name = "dpm-critical-temp-factor"

