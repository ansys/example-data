#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class ablation_select_model(String):
    """
    'ablation_select_model' child.
    """

    fluent_name = "ablation-select-model"

