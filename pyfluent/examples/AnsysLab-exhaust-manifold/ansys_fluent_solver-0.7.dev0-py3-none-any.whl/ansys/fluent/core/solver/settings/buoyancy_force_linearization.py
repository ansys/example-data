#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class buoyancy_force_linearization(Boolean):
    """
    Enable/disable linearized buoyancy force.
    """

    fluent_name = "buoyancy-force-linearization?"

