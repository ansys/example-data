#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class components(Boolean):
    """
    'components' child.
    """

    fluent_name = "components?"

