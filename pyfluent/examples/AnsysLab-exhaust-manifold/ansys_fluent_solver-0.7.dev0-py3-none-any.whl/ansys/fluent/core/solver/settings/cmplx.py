#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class cmplx(Boolean):
    """
    'cmplx' child.
    """

    fluent_name = "cmplx?"

