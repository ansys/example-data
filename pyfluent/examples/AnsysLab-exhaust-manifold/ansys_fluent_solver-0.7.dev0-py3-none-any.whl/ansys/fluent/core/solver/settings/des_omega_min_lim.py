#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class des_omega_min_lim(Real):
    """
    Set minimum allowable omega.
    """

    fluent_name = "des-omega-min-lim"

