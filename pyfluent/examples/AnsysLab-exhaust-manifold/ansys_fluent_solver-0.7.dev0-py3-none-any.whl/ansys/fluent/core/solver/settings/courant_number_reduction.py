#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class courant_number_reduction(Real):
    """
    Coarse-grid Courant number reduction factor.
    """

    fluent_name = "courant-number-reduction"

