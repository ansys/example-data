#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class contour_lines(Boolean):
    """
    'contour_lines' child.
    """

    fluent_name = "contour-lines?"

