#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class casm_cutoff_multiplier(Real):
    """
    Enter CASM cut-off multiplier :.
    """

    fluent_name = "casm-cutoff-multiplier"

