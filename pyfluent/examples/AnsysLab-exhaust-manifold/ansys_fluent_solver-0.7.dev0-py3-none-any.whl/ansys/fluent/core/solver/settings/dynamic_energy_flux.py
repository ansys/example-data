#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class dynamic_energy_flux(Boolean):
    """
    Enable/disable the dynamic sub-grid scale turbulent Prandtl Number.
    """

    fluent_name = "dynamic-energy-flux"

