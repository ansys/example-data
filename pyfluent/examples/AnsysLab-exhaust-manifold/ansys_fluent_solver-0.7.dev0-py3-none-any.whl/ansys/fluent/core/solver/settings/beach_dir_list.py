#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

from .beach_dir_list_child import beach_dir_list_child

class beach_dir_list(ListObject[beach_dir_list_child]):
    """
    'beach_dir_list' child.
    """

    fluent_name = "beach-dir-list"

    child_object_type: beach_dir_list_child = beach_dir_list_child
    """
    child_object_type of beach_dir_list.
    """
