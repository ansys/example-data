#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class display_clipped_pressure(Boolean):
    """
    Clipped pressure is just used for the properties evaluation. Mass Transfer Rate uses unclipped pressure.
    """

    fluent_name = "display-clipped-pressure?"

