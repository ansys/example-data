#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class ac_options(String):
    """
    'ac_options' child.
    """

    fluent_name = "ac-options"

