#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class convergence_acc_std_meshes(Boolean):
    """
    Enable/disable use of convergence acceleration for stretched meshes (CASM).
    """

    fluent_name = "convergence-acc-std-meshes?"

