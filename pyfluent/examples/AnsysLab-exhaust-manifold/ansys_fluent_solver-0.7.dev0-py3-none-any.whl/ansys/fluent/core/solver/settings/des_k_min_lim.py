#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class des_k_min_lim(Real):
    """
    Set minimum allowable k.
    """

    fluent_name = "des-k-min-lim"

