#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class disable_warped_face_gradient_correction(Command):
    """
    'disable_warped_face_gradient_correction' command.
    """

    fluent_name = "disable-warped-face-gradient-correction"

