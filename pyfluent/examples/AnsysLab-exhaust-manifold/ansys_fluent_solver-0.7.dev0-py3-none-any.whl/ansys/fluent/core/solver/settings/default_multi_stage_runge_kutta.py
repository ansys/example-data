#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class default_multi_stage_runge_kutta(Boolean):
    """
    'default_multi_stage_runge_kutta' child.
    """

    fluent_name = "default-multi-stage-runge-kutta?"

