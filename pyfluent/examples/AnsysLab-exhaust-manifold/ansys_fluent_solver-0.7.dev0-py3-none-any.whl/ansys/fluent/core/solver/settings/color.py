#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class color(String):
    """
    'color' child.
    """

    fluent_name = "color"

