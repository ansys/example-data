#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class equ_required(Boolean):
    """
    'equ_required' child.
    """

    fluent_name = "equ-required?"

