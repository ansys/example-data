#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_fs_level(Real):
    """
    'beach_fs_level' child.
    """

    fluent_name = "beach-fs-level"

