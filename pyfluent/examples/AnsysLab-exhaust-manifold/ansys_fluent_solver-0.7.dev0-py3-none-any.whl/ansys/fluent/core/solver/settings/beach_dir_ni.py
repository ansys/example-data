#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_dir_ni(Real):
    """
    'beach_dir_ni' child.
    """

    fluent_name = "beach-dir-ni"

