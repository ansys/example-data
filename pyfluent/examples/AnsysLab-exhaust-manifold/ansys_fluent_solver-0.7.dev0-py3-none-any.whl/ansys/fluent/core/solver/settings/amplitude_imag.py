#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class amplitude_imag(Real):
    """
    'amplitude_imag' child.
    """

    fluent_name = "amplitude-imag"

