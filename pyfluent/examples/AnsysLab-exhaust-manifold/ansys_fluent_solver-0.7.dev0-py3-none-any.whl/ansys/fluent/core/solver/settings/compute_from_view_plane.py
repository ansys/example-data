#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class compute_from_view_plane(Boolean):
    """
    'compute_from_view_plane' child.
    """

    fluent_name = "compute-from-view-plane?"

