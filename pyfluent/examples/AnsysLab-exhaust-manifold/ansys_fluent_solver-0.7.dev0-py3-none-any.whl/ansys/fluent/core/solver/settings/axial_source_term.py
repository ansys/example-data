#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class axial_source_term(Boolean):
    """
    'axial_source_term' child.
    """

    fluent_name = "axial-source-term"

