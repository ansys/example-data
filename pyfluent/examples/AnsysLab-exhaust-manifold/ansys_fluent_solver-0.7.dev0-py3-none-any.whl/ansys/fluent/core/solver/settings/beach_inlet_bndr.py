#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class beach_inlet_bndr(String):
    """
    'beach_inlet_bndr' child.
    """

    fluent_name = "beach-inlet-bndr"

