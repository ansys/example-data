#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class error_tolerance(Real):
    """
    Set Truncation Error Tolerance.
    """

    fluent_name = "error-tolerance"

