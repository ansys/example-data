#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class depth(Real):
    """
    Set reference depth for volume calculation.
    """

    fluent_name = "depth"

