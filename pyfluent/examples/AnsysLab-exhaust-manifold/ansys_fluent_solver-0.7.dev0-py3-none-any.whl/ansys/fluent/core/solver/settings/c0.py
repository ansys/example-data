#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class c0(Real):
    """
    'c0' child.
    """

    fluent_name = "c0"

