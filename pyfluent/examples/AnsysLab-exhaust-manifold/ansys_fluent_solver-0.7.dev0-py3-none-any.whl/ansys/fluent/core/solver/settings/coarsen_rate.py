#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.fluent.core.solver.flobject import *

class coarsen_rate(Integer):
    """
    Set AMG coarsening rate.
    """

    fluent_name = "coarsen-rate"

